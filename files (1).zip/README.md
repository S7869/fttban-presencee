# FTTBAN Presence

Static blog for GitHub Pages: HTML, CSS and vanilla JavaScript only.

## Publish
1. Create a GitHub repository and upload these files (keep `index.html` at the root).
2. Settings > Pages > Deploy from a branch > `main` / root.
3. Replace `YOUR-USERNAME` in the canonical and Open Graph URLs in each HTML file.

## Add an article
Open `script.js`, find `ADD NEW ARTICLES HERE`, copy an object, give it a new unique `id`. Content format: blank line between blocks; `## ` heading; `- ` bullets; `> ` quote.

## Other edits
- Colors and fonts: CSS variables at the top of `style.css`.
- Social links: the `#` placeholders in the footer in `script.js`.
- Contact form: see the comments in `contact.html` and the end of `script.js` (Formspree).
