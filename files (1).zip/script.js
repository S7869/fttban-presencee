// ===============================
// ADD NEW ARTICLES HERE
// Copy one object, give it a new unique id, and save. Everything else updates automatically.
// Content format: blank line between blocks. "## " = heading, "- " = bullet list, "> " = quote, otherwise paragraph.
// ===============================
const CATEGORIES = ["Technology","Blogging","Business","Productivity","Digital Life","Creator"];
const articles = [
{id:1,title:"How AI Is Changing Everyday Work",category:"Technology",date:"September 28, 2026",author:"FTTBAN Editorial",readingTime:"6 min read",excerpt:"AI tools are quietly reshaping routine tasks. Here is where they genuinely help and where human judgment still wins.",
content:"AI is no longer a novelty. For many people it already drafts emails, summarizes meetings and sorts data before the first coffee is finished.\n\n## Where AI helps most\nThe best results come from repetitive, well-defined tasks where a first draft saves time and a person still reviews the output.\n\n- Drafting and rewriting routine messages\n- Summarizing long documents and meetings\n- Brainstorming options before you decide\n\n> Treat AI as a fast assistant, not an authority.\n\n## Where people still matter\nContext, taste and accountability remain human work. Verify facts, protect private data and keep your own voice in anything you publish."},
{id:2,title:"Starting Your First Blog From Zero",category:"Blogging",date:"September 24, 2026",author:"Amara Cole",readingTime:"5 min read",excerpt:"You do not need a perfect plan. You need a topic, a schedule and the patience to publish before you feel ready.",
content:"Most blogs fail not from bad ideas but from never shipping the first ten posts. Start small and make publishing a habit.\n\n## Choose a clear topic\nPick a subject you can write about for a year. Narrow beats broad: a blog about practical budgeting will outgrow one about everything.\n\n- Define who you are writing for\n- List twenty post ideas before launching\n- Choose a realistic schedule, such as one post a week\n\n> Publishing imperfectly beats polishing forever.\n\n## Keep it simple\nA clean layout, readable fonts and a single email signup are enough. Improve the design after you have readers."},
{id:3,title:"Small Habits That Create Big Changes",category:"Productivity",date:"September 20, 2026",author:"Jordan Reyes",readingTime:"5 min read",excerpt:"Tiny, repeatable actions compound faster than dramatic resolutions. Start with two minutes a day.",
content:"Big goals fail when they rely on motivation. Small habits work because they fit into the day you already have.\n\n## Make it tiny\nIf a habit takes less than two minutes, it is hard to skip. Read one page. Write one sentence. Stretch for sixty seconds.\n\n- Attach new habits to existing routines\n- Track streaks on paper or a simple app\n- Prepare tomorrow's first task tonight\n\n> You do not rise to your goals; you fall to your systems.\n\n## Be patient\nResults appear slowly, then suddenly. Review monthly, not daily, and adjust only what is clearly not working."},
{id:4,title:"Skills That Can Build Your Online Career",category:"Digital Life",date:"September 16, 2026",author:"Amara Cole",readingTime:"6 min read",excerpt:"From writing to data literacy, these skills stay valuable no matter which platform is trending.",
content:"Platforms change quickly, but the skills behind good online work last. Focus on the foundations.\n\n## Core skills to learn\nClear communication is the base. Add one technical and one creative skill and you become hard to replace.\n\n- Writing and editing for the web\n- Basic data analysis and spreadsheets\n- Design fundamentals and simple video editing\n- Search and audience research\n\n> Skills compound when you apply them to real projects.\n\n## Prove it publicly\nBuild a small portfolio. Real examples, even personal ones, persuade more than certificates."},
{id:5,title:"Building a Content System That Lasts",category:"Creator",date:"September 12, 2026",author:"Jordan Reyes",readingTime:"7 min read",excerpt:"Consistency comes from process. Learn how to capture, create and repurpose ideas without burning out.",
content:"Creators rarely run out of talent. They run out of systems. A simple pipeline keeps ideas flowing.\n\n## Capture, draft, publish\nKeep one inbox for ideas. Batch drafting in focused sessions, and schedule publishing separately so quality does not depend on mood.\n\n- Collect ideas in one notes app\n- Draft in batches of two or three pieces\n- Repurpose one article into a thread, a newsletter and a short video\n\n> A system lets you create on your worst day.\n\n## Review and refine\nOnce a month, look at what readers finished and shared. Do more of that."},
{id:6,title:"Learning in Public: Why It Works",category:"Creator",date:"September 8, 2026",author:"Sam Okafor",readingTime:"5 min read",excerpt:"Sharing what you are learning builds skill, trust and connections faster than studying alone.",
content:"Learning in public means sharing your progress, notes and mistakes as you go. It sounds risky, but it is one of the fastest ways to grow.\n\n## Why it helps\nTeaching forces clarity. Feedback arrives sooner, and others on the same path find you.\n\n- Write short notes after each lesson\n- Share projects at the unfinished stage\n- Credit sources and thank people who help\n\n> Your confusion today is someone else's guide tomorrow.\n\n## Start gently\nPost weekly, stay honest about what you do not know, and let a record of progress build your reputation."},
{id:7,title:"How to Stay Productive in a Digital World",category:"Productivity",date:"September 4, 2026",author:"Jordan Reyes",readingTime:"6 min read",excerpt:"Notifications, tabs and feeds compete for your focus. Take it back with a few deliberate boundaries.",
content:"Constant connection makes busy feel like productive. Real focus needs boundaries that you set on purpose.\n\n## Protect your attention\nDecide when you check messages instead of reacting to every ping. Your best hours should go to your most important work.\n\n- Turn off non-essential notifications\n- Work in 50-minute focus blocks with short breaks\n- Keep one visible list of three priorities\n\n> Attention is the scarcest resource you own.\n\n## Rest on purpose\nSleep, movement and time offline are productivity tools, not rewards."},
{id:8,title:"The Beginner's Guide to Personal Branding",category:"Business",date:"August 30, 2026",author:"Amara Cole",readingTime:"6 min read",excerpt:"A personal brand is simply what people trust you for. Here is how to shape it with honesty and consistency.",
content:"Personal branding is not self-promotion. It is the reputation you build by being clear and reliable about what you do.\n\n## Define your focus\nAnswer three questions: who do you help, with what, and how are you different?\n\n- Write a one-sentence description of your work\n- Use the same name, photo and tone across platforms\n- Share useful work regularly, not just announcements\n\n> Reputation is built from small promises kept.\n\n## Stay authentic\nAudiences notice when a persona feels forced. Keep your values stable and let your style evolve."},
{id:9,title:"Turning Ideas Into Useful Content",category:"Blogging",date:"August 26, 2026",author:"Sam Okafor",readingTime:"5 min read",excerpt:"Good ideas are common. Useful content solves a specific problem for a specific reader.",
content:"An idea becomes content when it helps someone do something. Begin with the reader's problem, not your outline.\n\n## From idea to outline\nWrite the question your reader is asking, then answer it in plain steps with one example.\n\n- State the problem in the first paragraph\n- Give steps the reader can try today\n- End with a clear next action\n\n> If it cannot be used, it is not finished.\n\n## Edit for clarity\nCut every sentence that does not help. Short, specific writing earns trust and gets shared."}
];
// ===============================

const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const ci=c=>Math.max(0,CATEGORIES.indexOf(c));
const esc=s=>String(s).replace(/[&<>"]/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[m]));
const link=a=>`blog.html#article-${a.id}`;

function card(a,big){return `<article class="card"><a class="thumb c${ci(a.category)}" href="${link(a)}" tabindex="-1" aria-hidden="true">${esc(a.category)}</a><div class="cb"><p class="cat">${esc(a.category)}</p><h3><a href="${link(a)}">${esc(a.title)}</a></h3><p class="muted">${esc(a.excerpt)}</p><p class="meta"><span>${esc(a.author)}</span><span>${esc(a.date)}</span><span>${esc(a.readingTime)}</span></p>${big?`<p><a class="btn alt" href="${link(a)}">Read Article</a></p>`:""}</div></article>`}

function parse(t){return t.split("\n\n").map(b=>b.startsWith("## ")?`<h2>${esc(b.slice(3).split("\n")[0])}</h2>${(b.split("\n").slice(1).join(" ")).trim()?`<p>${esc(b.split("\n").slice(1).join(" "))}</p>`:""}`:b.startsWith("- ")?`<ul>${b.split("\n").map(l=>`<li>${esc(l.slice(2))}</li>`).join("")}</ul>`:b.startsWith("> ")?`<blockquote>${esc(b.slice(2))}</blockquote>`:`<p>${esc(b)}</p>`).join("")}

// Shared layout
const pages=[["index.html","Home"],["blog.html","Blog"],["blog.html#categories","Categories"],["about.html","About"],["contact.html","Contact"]];
const social=["Instagram","Facebook","X","YouTube","LinkedIn"];
const here=location.pathname.split("/").pop()||"index.html";
$("#site-header").outerHTML=`<header class="site"><div class="wrap"><a class="logo" href="index.html">FTTBAN Presence</a><div style="display:flex;gap:8px;align-items:center"><nav id="nav" aria-label="Main navigation"><ul>${pages.map(([h,n])=>`<li><a href="${h}" ${h===here?'class="on" aria-current="page"':""}>${n}</a></li>`).join("")}</ul></nav><button class="icon-btn" id="theme" aria-label="Toggle dark mode">Theme</button><button id="menu" aria-label="Open menu" aria-expanded="false" aria-controls="nav">Menu</button></div></div></header>`;
$("#site-footer").outerHTML=`<footer class="site"><div class="wrap"><div class="fcols"><div><a class="logo" href="index.html">FTTBAN Presence</a><p class="muted">Ideas. Stories. Insights.</p></div><ul aria-label="Footer navigation">${pages.map(([h,n])=>`<li><a href="${h}">${n}</a></li>`).join("")}</ul><ul aria-label="Social links"><!-- REPLACE the # links below with your real social profile URLs -->${social.map(s=>`<li><a href="#" aria-label="${s} (placeholder link)">${s}</a></li>`).join("")}</ul></div><p class="copy">&copy; <span id="year"></span> FTTBAN Presence. All rights reserved.</p></div></footer>`;
$("#year").textContent=new Date().getFullYear();
document.body.insertAdjacentHTML("afterbegin",'<div id="progress"></div>');
document.body.insertAdjacentHTML("beforeend",'<button class="btn" id="top" aria-label="Back to top">Top</button>');
const nl=$("#newsletter");if(nl)nl.innerHTML=`<div class="news wrap"><h2>Stay connected with FTTBAN Presence</h2><p>Get new articles, useful ideas and practical guides delivered to your inbox.</p><form id="nlform"><label class="sr" for="nlmail" style="position:absolute;left:-9999px">Email address</label><input id="nlmail" type="email" required placeholder="Email address"><button class="btn" type="submit">Subscribe</button></form><p class="ok" id="nlmsg" role="status"></p></div>`;
$("#nlform")?.addEventListener("submit",e=>{e.preventDefault();$("#nlmsg").textContent="Thanks for subscribing! This is a demo interaction, so no email was saved.";e.target.reset()});

// Theme, menu, progress, top button
const root=document.documentElement;try{root.dataset.theme=localStorage.getItem("theme")||(matchMedia("(prefers-color-scheme:dark)").matches?"dark":"light")}catch(e){}
$("#theme").onclick=()=>{root.dataset.theme=root.dataset.theme==="dark"?"light":"dark";try{localStorage.setItem("theme",root.dataset.theme)}catch(e){}};
$("#menu").onclick=e=>{const o=$("#nav").classList.toggle("open");e.target.setAttribute("aria-expanded",o)};
addEventListener("scroll",()=>{const h=document.documentElement,m=h.scrollHeight-h.clientHeight;$("#progress").style.width=(m>0?h.scrollTop/m*100:0)+"%";$("#top").style.display=h.scrollTop>500?"block":"none"},{passive:true});
$("#top").onclick=()=>scrollTo({top:0});

// Home
if($("#featured"))$("#featured").innerHTML=articles.slice(0,3).map(a=>card(a,true)).join("");
if($("#latest")&&!$("#blog-app"))$("#latest").innerHTML=articles.map(a=>card(a)).join("");

// Blog: search, filter, reader
if($("#blog-app")){let cat="All",q="";
 $("#chips").innerHTML=["All",...CATEGORIES].map(c=>`<button class="chip" aria-pressed="${c==="All"}" data-c="${c}">${c} (${c==="All"?articles.length:articles.filter(a=>a.category===c).length})</button>`).join("");
 const draw=()=>{const l=articles.filter(a=>(cat==="All"||a.category===cat)&&(a.title+a.excerpt+a.category+a.content).toLowerCase().includes(q));
  $("#latest").innerHTML=l.length?l.map(a=>card(a)).join(""):`<p class="empty">No articles found</p>`;
  $("#count").textContent=`${l.length} article${l.length===1?"":"s"} shown`;
  $$(".chip").forEach(b=>b.setAttribute("aria-pressed",b.dataset.c===cat))};
 $("#chips").onclick=e=>{const b=e.target.closest("[data-c]");if(b){cat=b.dataset.c;draw()}};
 $("#search").oninput=e=>{q=e.target.value.trim().toLowerCase();draw()};
 const route=()=>{const m=location.hash.match(/^#article-(\d+)$/),a=m&&articles.find(x=>x.id==m[1]);
  $("#list").hidden=!!a;$("#reader").hidden=!a;if(!a){draw();return}
  document.title=a.title+" | FTTBAN Presence";
  const rel=articles.filter(x=>x.id!==a.id).sort((x,y)=>(y.category===a.category)-(x.category===a.category)).slice(0,3);
  $("#reader").innerHTML=`<article class="reader wrap"><a class="btn alt" href="blog.html">Back to Blog</a><p class="cat" style="margin-top:28px">${esc(a.category)}</p><h1>${esc(a.title)}</h1><p class="meta"><span>By ${esc(a.author)}</span><span>${esc(a.date)}</span><span>${esc(a.readingTime)}</span></p><div class="thumb c${ci(a.category)}" role="img" aria-label="${esc(a.category)} article visual">${esc(a.category)}</div><p class="lead muted"><em>${esc(a.excerpt)}</em></p>${parse(a.content)}<div class="acts"><button class="btn" id="share">Share article</button><button class="btn alt" id="copy">Copy link</button></div><p class="ok" id="smsg" role="status"></p></article><section class="wrap s"><h2>Related articles</h2><div class="grid">${rel.map(x=>card(x)).join("")}</div></section>`;
  $("#share").onclick=async()=>{const u=location.href;if(navigator.share){try{await navigator.share({title:a.title,text:a.excerpt,url:u})}catch(e){}}else cp(u)};
  $("#copy").onclick=()=>cp(location.href);scrollTo({top:0})};
 const cp=async u=>{try{await navigator.clipboard.writeText(u);$("#smsg").textContent="Link copied to clipboard."}catch(e){prompt("Copy this link:",u)}};
 addEventListener("hashchange",route);route();
 if(location.hash==="#categories")setTimeout(()=>$("#categories")?.scrollIntoView(),50);
}

// Contact (demo). To go live, set the form's action to your Formspree URL and remove the preventDefault block.
$("#contact-form")?.addEventListener("submit",e=>{e.preventDefault();$("#cmsg").textContent="Thanks for reaching out! This demo form has been submitted.";e.target.reset()});
